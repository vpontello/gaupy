from setuptools import setup

setup(name="gaupy", 
 version="1.0",
 description="Gaussian and Binomial distributions",
 packages=['gaupy'],
 author='Victor Pontello',
 author_email='vpontello@outlook.com',
 zip_safe=False)